package com.cardinal.test;

import org.junit.Test;
import static org.junit.Assert.*;
import com.cardinal.ConwayGameOfLife;

public class ConwayGameOfLifeTest {
	@Test
    public void testUnderpopulation() {
        int [][] inputData = {
        						{1,0,0},
        						{1,0,0},
        						{1,0,0}
        };
        ConwayGameOfLife gameOfLife = new ConwayGameOfLife(inputData);
        assertEquals(0, gameOfLife.getNextState(0, 0));
    }
	@Test
    public void testOverCrowding() {
        int [][] inputData = {
        						{1,0,0},
        						{1,1,0},
        						{1,1,0}
        };
        ConwayGameOfLife gameOfLife = new ConwayGameOfLife(inputData);
        assertEquals(0, gameOfLife.getNextState(1, 0));
    }
	@Test
    public void testLivesToNextGeneration() {
        int [][] inputData = {
        						{1,0,0,0,0},
        						{1,1,0,1,1},
        						{1,0,0,0,1}
        };
        ConwayGameOfLife gameOfLife = new ConwayGameOfLife(inputData);
       
        assertEquals(1, gameOfLife.getNextState(1, 0));
        assertEquals(1, gameOfLife.getNextState(1, 4));
    }

	@Test
    public void testDeadBecomesAlive() {
        int [][] inputData = {
        						{1,0,0,0,0},
        						{0,1,1,1,1},
        						{1,0,0,0,1}
        };
        ConwayGameOfLife gameOfLife = new ConwayGameOfLife(inputData);
       
        assertEquals(1, gameOfLife.getNextState(1, 0));
        assertEquals(0, gameOfLife.getNextState(2, 3));
    }

}
