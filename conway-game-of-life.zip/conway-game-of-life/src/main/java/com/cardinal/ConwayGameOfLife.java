package com.cardinal;

public class ConwayGameOfLife {
	
	public ConwayGameOfLife()
	{
		
	}
	
	public ConwayGameOfLife(int[][] inputGrid) {
		this.inputGrid = inputGrid;
		noOfRows = inputGrid.length;
		noOfColumns = inputGrid[0].length;
		
		outputGrid = new int [noOfRows][noOfColumns];
	}
	
	private int [][] inputGrid;
	
	private int [][] outputGrid;

	private int noOfRows;
	
	private int noOfColumns;
	
	public int[][] getInputGrid() {
		return inputGrid;
	}

	public void setInputGrid(int[][] inputGrid) {
		this.inputGrid = inputGrid;
	}

	public int[][] getOutputGrid() {
		return outputGrid;
	}

	public void setOutputGrid(int[][] outputGrid) {
		this.outputGrid = outputGrid;
	}
	
	public void displayInput()
	{
		System.out.println("Printing Input Grid:");
		System.out.println("____________________");
		for(int i=0;i<noOfRows;i++)
		{
			for(int j=0;j<noOfColumns;j++)
			{
				System.out.print(inputGrid[i][j]);
			}
			System.out.println("");
		}
		System.out.println("____________________");
	}
	public void displayOutput()
	{
		System.out.println("Printing Output Grid:");
		System.out.println("____________________");
		for(int i=0;i<noOfRows;i++)
		{
			for(int j=0;j<noOfColumns;j++)
			{
				System.out.print(outputGrid[i][j]);
			}
			System.out.println("");
		}
		System.out.println("____________________");
	}
	public void generateNextLife()
	{
		for(int i=0;i<noOfRows;i++)
		{
			for(int j=0;j<noOfColumns;j++)
			{
				outputGrid[i][j] = getNextState(i,j);				
			}
		}
	}
	public int getNextState(int rowPos,int colPos)
	{
		int neighborsSum = 0;

		if((rowPos-1)>=0)
		{
			if((colPos-1)>=0)
			{
				neighborsSum+=inputGrid[rowPos-1][colPos-1];
				neighborsSum+=inputGrid[rowPos][colPos-1];
			}
			if((colPos+1)<noOfColumns)
			{
				neighborsSum+=inputGrid[rowPos-1][colPos+1];
				neighborsSum+=inputGrid[rowPos][colPos+1];
			}
			neighborsSum+=inputGrid[rowPos-1][colPos];
		}	
			
		if((rowPos+1)< noOfRows)
		{
			if((colPos-1)>=0)
			{
				neighborsSum+=inputGrid[rowPos+1][colPos-1];
				
			}
			if((colPos+1)<noOfColumns)
			{
				neighborsSum+=inputGrid[rowPos+1][colPos+1];
				
			}
			neighborsSum+=inputGrid[rowPos+1][colPos];
		}	
			neighborsSum+=inputGrid[rowPos][colPos];
		//System.out.println("neighborsSum:"+neighborsSum);
		if(neighborsSum==3)
			return 1;
		else if(neighborsSum==4)
			return inputGrid[rowPos][colPos];
		else
			return 0;
	}
}
