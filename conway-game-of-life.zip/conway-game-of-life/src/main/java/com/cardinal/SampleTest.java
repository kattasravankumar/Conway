package com.cardinal;

import java.util.Scanner;
import java.util.StringTokenizer;

public class SampleTest {
	public static void main(String [] args)
	{
		ConwayGameOfLife gameOfLife;
		int [][] inputGrid ;
		int [][] sampleInputGrid = {
				{0,0,0,0,0,0,1,0},
				{1,1,1,0,0,0,1,0},
				{0,0,0,0,0,0,1,0},
				{0,0,0,0,0,0,0,0},
				{0,0,0,1,1,0,0,0},
				{0,0,0,1,1,0,0,0}
			};
		Scanner input = new Scanner (System.in);
		String executionChoice ;
        while(true)
        {
        	System.out.print("Enter your choice of execution : S for sample input and C for Custom Input and X to Exit:");
    		
        	executionChoice = input.next();
        	if(executionChoice!=null && executionChoice.equalsIgnoreCase("S"))
	        {
	        	
	        	inputGrid = sampleInputGrid;
	        	gameOfLife = new ConwayGameOfLife(inputGrid);
	            gameOfLife.generateNextLife();
	            gameOfLife.displayOutput();
	        }
	        else if (executionChoice!=null && executionChoice.equalsIgnoreCase("C")){
	        	
	        	System.out.print ("Enter the number of rows ");
	            int noOfRows = Integer.parseInt(input.next());
	
	            System.out.print ("Enter the number of Columns ");
	            int noOfColumns = Integer.parseInt(input.next());
	            
	            inputGrid= new int [noOfRows][noOfColumns];
	            
	            System.out.println("Size if Grid is :"+noOfRows+"X"+noOfColumns);
	            
	            for(int i=0;i<noOfRows;i++)
	    		{	
	    			System.out.println("Key in the data for Row Number "+(i+1));
	    			String rowData = input.next();
	    			StringTokenizer st = new StringTokenizer(rowData,",");
	    			if(st.countTokens()!=noOfColumns)
	    			{
	    				System.out.println("Invalid Input");
	    				i--;
	    			}
	    			else
	    			{
	    				int columnNumber = 0;
	    				int cellValue = 0;
	    				while(st.hasMoreTokens())
	    				{
	    					try
	    					{
	    						cellValue = Integer.parseInt(st.nextToken());
								
	    						inputGrid[i][columnNumber++] = cellValue;
	    					}
	    					catch(NumberFormatException ne)
	    					{
	    						System.out.println("Invalid Input");
	    						i--;
	    					}
	    					catch(NullPointerException npe)
	    					{
	    						System.out.println("Invalid Input");
	    						i--;
	    					}
	    				}
	    			}
	    		}
	            gameOfLife = new ConwayGameOfLife(inputGrid);
	            while(true){
	            	gameOfLife.generateNextLife();
		            gameOfLife.displayOutput();
		            System.out.println("Do you want to execute next iteration with this Out Put:N for next Iteration Other to Main menu");
		            String nextOption = input.next();
		            if(nextOption!=null && nextOption.equalsIgnoreCase("N"))
		            {
		            	gameOfLife.setInputGrid(gameOfLife.getOutputGrid());
		            }
		            else
		            	break;
	            }
	        	
	            
	        }
	        else if (executionChoice!=null && executionChoice.equalsIgnoreCase("X"))
	        {
	        	System.out.println("Exiting the Program.");
	        	input.close();
	        	System.exit(0);
	        }
	        else
	        {
	        	System.out.println("Invalid Choice of Execution.");
	        	System.out.print("Enter your choice of execution : S for sample input and C for Custom Input and X to Exit:");
	        }
        }
	}
}
